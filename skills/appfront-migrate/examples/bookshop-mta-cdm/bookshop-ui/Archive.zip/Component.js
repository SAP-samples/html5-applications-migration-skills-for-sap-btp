sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("bookshopapp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map